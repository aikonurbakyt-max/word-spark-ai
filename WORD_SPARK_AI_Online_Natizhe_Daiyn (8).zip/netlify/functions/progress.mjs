import {getStore} from '@netlify/blobs';
import {createHash,timingSafeEqual} from 'node:crypto';
const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'same-origin'};
const json=(obj,status=200)=>new Response(JSON.stringify(obj),{status,headers});
const clean=x=>String(x??'').normalize('NFC').replace(/\s+/g,' ').trim();
const normalize=x=>clean(x).toLocaleLowerCase('kk-KZ').replace(/[.,‘’'\u2019-]/g,' ').replace(/\s+/g,' ').replace(/ё/g,'е');
const allowed=/^(wordspark-|word-spark-|ws_sparky_)[\wа-яА-ЯёЁәғқңөұүһіӘҒҚҢӨҰҮҺІ.\-]+$/;
const hash=s=>createHash('sha256').update(s).digest('hex');
const identity=(classId,name)=>classId+'/'+hash(classId+'|'+normalize(name));
const valid=(classId,name)=>['3A','4B'].includes(classId)&&typeof name==='string'&&clean(name).length>=3&&clean(name).length<=100;
const authorized=req=>{const expected=process.env.TEACHER_ACCESS_KEY||'',given=req.headers.get('X-Teacher-Key')||'';return expected.length>=16&&Buffer.byteLength(expected)===Buffer.byteLength(given)&&timingSafeEqual(Buffer.from(expected),Buffer.from(given))};
function summarize(items){const s={lessons:0,sentences:0,memory:0,speed:0,dialogues:0,words:0,stars:0,updatedAt:''};
 for(const r of items){if(r.updatedAt>s.updatedAt)s.updatedAt=r.updatedAt;let data;try{data=JSON.parse(r.value)}catch{continue}
 const k=r.key;
 if(k.startsWith('wordspark-progress-grade-')){s.lessons=Math.max(s.lessons,Number(data.sessions)||0);s.words=Math.max(s.words,Number(data.totalWords||data.uniqueWords||0));s.stars=Math.max(s.stars,Number(data.stars)||0)}
 if(k.startsWith('wordspark-sentence-v1-'))s.sentences=Math.max(s.sentences,Array.isArray(data)?data.length:0);
 if(k.startsWith('wordspark-memory-stats-v2-'))s.memory=Math.max(s.memory,Array.isArray(data.sessions)?data.sessions.length:Number(data.sessions)||0);
 if(k.startsWith('word-spark-speed-'))s.speed=Math.max(s.speed,Array.isArray(data)?data.length:0);
 if(k.startsWith('ws_sparky_'))s.dialogues=Math.max(s.dialogues,Array.isArray(data)?data.length:0);
 }
 return s}
async function collect(store,prefix){const data=await store.list({prefix,paginate:true});const entries=[];if(Symbol.asyncIterator in Object(data)){for await(const part of data){entries.push(...(part.blobs||[]));if(entries.length>=3000)break}}else entries.push(...(data.blobs||[]));return entries.slice(0,3000)}
export default async function handler(request){try{
 const store=getStore('word-spark-results');const url=new URL(request.url);
 if(request.method==='POST'){
  if(Number(request.headers.get('content-length')||0)>26000)return json({error:'Дерек тым үлкен'},413);
  const obj=await request.json();const {classId,name,key,value}=obj||{};
  if(!valid(classId,name)||typeof key!=='string'||!allowed.test(key)||key.length>140||typeof value!=='string'||value.length>18000)return json({error:'Нәтиже өрістері дұрыс емес'},400);
  const user=identity(classId,name);const itemKey='results/'+user+'/'+hash(key).slice(0,20);
  const old=await store.get(itemKey,{type:'json'}).catch(()=>null);
  if(old?.value===value)return json({ok:true,unchanged:true});
  await store.setJSON(itemKey,{classId,name:clean(name),key,value,updatedAt:new Date().toISOString()});
  return json({ok:true});
 }
 if(request.method==='GET'){
  const view=url.searchParams.get('view');
  if(view==='student'){
   const classId=url.searchParams.get('classId'),name=url.searchParams.get('name');
   if(!valid(classId,name))return json({error:'Сынып пен аты-жөні қажет'},400);
   // Name-only login cannot provide verified identity: only return learning metrics, no personal contact details.
   const entries=await collect(store,'results/'+identity(classId,name)+'/');const items=[];
   for(const e of entries.slice(0,60)){const v=await store.get(e.key,{type:'json'}).catch(()=>null);if(v&&v.classId===classId&&normalize(v.name)===normalize(name))items.push({key:v.key,value:v.value,updatedAt:v.updatedAt})}
   return json({items,summary:summarize(items)});
  }
  if(view==='teacher'){
   if(!process.env.TEACHER_ACCESS_KEY||process.env.TEACHER_ACCESS_KEY.length<16)return json({error:'Netlify-де TEACHER_ACCESS_KEY орнатылмаған (16 таңбадан кем емес)'},503);
   if(!authorized(request))return json({error:'Мұғалім кілті дұрыс емес'},401);
   const records=[];for(const classId of ['3A','4B']){
    const entries=await collect(store,'results/'+classId+'/');
    for(const e of entries){const r=await store.get(e.key,{type:'json'}).catch(()=>null);if(r&&r.classId===classId&&valid(r.classId,r.name))records.push(r)}
   }
   const grouped=new Map();for(const record of records){const id=identity(record.classId,record.name);if(!grouped.has(id))grouped.set(id,[]);grouped.get(id).push(record)}
   const students=[...grouped.values()].map(items=>({classId:items[0].classId,name:items[0].name,...summarize(items)})).sort((a,b)=>a.classId.localeCompare(b.classId)||a.name.localeCompare(b.name,'kk'));
   return json({students});
  }
  return json({error:'view қажет'},400)
 }
 return json({error:'Әдіс қолжетімсіз'},405)
}catch(e){console.error('WORD SPARK API',e);return json({error:'Серверге қосыла алмады немесе нәтиже сақталмады'},500)}};
